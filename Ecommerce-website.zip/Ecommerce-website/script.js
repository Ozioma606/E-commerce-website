// Product data
const products = [
    {
        id: 1,
        name: "iPhone 15 Pro",
        price: 999.99,
        originalPrice: 1199.99,
        category: "smartphones",
        icon: "📱",
        description: "Latest iPhone with advanced camera system"
    },
    {
        id: 2,
        name: "MacBook Pro M3",
        price: 1999.99,
        originalPrice: 2299.99,
        category: "laptops",
        icon: "💻",
        description: "Powerful laptop for professionals"
    },
    {
        id: 3,
        name: "AirPods Pro",
        price: 249.99,
        originalPrice: 299.99,
        category: "accessories",
        icon: "🎧",
        description: "Wireless earbuds with noise cancellation"
    },
    {
        id: 4,
        name: "Samsung Galaxy S24",
        price: 899.99,
        originalPrice: 999.99,
        category: "smartphones",
        icon: "📱",
        description: "Android flagship with AI features"
    },
    {
        id: 5,
        name: "Dell XPS 13",
        price: 1299.99,
        originalPrice: 1499.99,
        category: "laptops",
        icon: "💻",
        description: "Ultra-thin laptop with premium build"
    },
    {
        id: 6,
        name: "Sony WH-1000XM5",
        price: 349.99,
        originalPrice: 399.99,
        category: "accessories",
        icon: "🎧",
        description: "Premium noise-canceling headphones"
    },
    {
        id: 7,
        name: "iPad Pro 12.9\"",
        price: 1099.99,
        originalPrice: 1299.99,
        category: "smartphones",
        icon: "📱",
        description: "Professional tablet with M2 chip"
    },
    {
        id: 8,
        name: "Surface Laptop 5",
        price: 1599.99,
        originalPrice: 1799.99,
        category: "laptops",
        icon: "💻",
        description: "Microsoft's premium laptop"
    },
    {
        id: 9,
        name: "Apple Watch Ultra",
        price: 799.99,
        originalPrice: 899.99,
        category: "accessories",
        icon: "⌚",
        description: "Rugged smartwatch for adventurers"
    }
];

// Shopping cart
let cart = [];
let currentFilter = 'all';

// DOM elements
const productsGrid = document.getElementById('productsGrid');
const cartSidebar = document.getElementById('cartSidebar');
const cartOverlay = document.getElementById('cartOverlay');
const cartItems = document.getElementById('cartItems');
const cartCount = document.getElementById('cartCount');
const cartTotal = document.getElementById('cartTotal');
const paymentModal = document.getElementById('paymentModal');
const successModal = document.getElementById('successModal');
const searchInput = document.getElementById('searchInput');

// Initialize the app
document.addEventListener('DOMContentLoaded', function() {
    renderProducts();
    updateCartDisplay();
    setupEventListeners();
});

// Setup event listeners
function setupEventListeners() {
    // Search functionality
    searchInput.addEventListener('input', handleSearch);

    // Payment form submission
    document.getElementById('paymentForm').addEventListener('submit', processPayment);

    // Card number formatting
    document.getElementById('cardNumber').addEventListener('input', formatCardNumber);
    document.getElementById('expiryDate').addEventListener('input', formatExpiryDate);
    document.getElementById('cvv').addEventListener('input', formatCVV);

    // Close modals when clicking outside
    paymentModal.addEventListener('click', function(e) {
        if (e.target === paymentModal) {
            closePaymentModal();
        }
    });

    successModal.addEventListener('click', function(e) {
        if (e.target === successModal) {
            closeSuccessModal();
        }
    });
}

// Render products
function renderProducts(productsToRender = products) {
    productsGrid.innerHTML = '';

    if (productsToRender.length === 0) {
        productsGrid.innerHTML = '<div class="no-products">No products found</div>';
        return;
    }

    productsToRender.forEach(product => {
        const productCard = createProductCard(product);
        productsGrid.appendChild(productCard);
    });
}

// Create product card
function createProductCard(product) {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.setAttribute('data-category', product.category);

    card.innerHTML = `
        <div class="product-image">
            ${product.icon}
        </div>
        <h3>${product.name}</h3>
        <p>${product.description}</p>
        <div class="product-price">
            ${product.originalPrice ? `<span class="original-price">$${product.originalPrice}</span>` : ''}
            $${product.price}
        </div>
        <button class="add-to-cart" onclick="addToCart(${product.id})">
            <i class="fas fa-shopping-cart"></i>
            Add to Cart
        </button>
    `;

    return card;
}

// Filter products
function filterProducts(category) {
    currentFilter = category;

    // Update active filter button
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');

    // Filter and render products
    const filteredProducts = category === 'all' 
        ? products 
        : products.filter(product => product.category === category);

    renderProducts(filteredProducts);
}

// Search functionality
function handleSearch(e) {
    const searchTerm = e.target.value.toLowerCase();
    const filteredProducts = products.filter(product => {
        const matchesSearch = product.name.toLowerCase().includes(searchTerm) ||
                            product.description.toLowerCase().includes(searchTerm);
        const matchesCategory = currentFilter === 'all' || product.category === currentFilter;
        return matchesSearch && matchesCategory;
    });

    renderProducts(filteredProducts);
}

// Add to cart
function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    const existingItem = cart.find(item => item.id === productId);

    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({ ...product, quantity: 1 });
    }

    updateCartDisplay();
    showNotification('Product added to cart!');
}

// Remove from cart
function removeFromCart(productId) {
    cart = cart.filter(item => item.id !== productId);
    updateCartDisplay();
    showNotification('Product removed from cart!');
}

// Update quantity
function updateQuantity(productId, change) {
    const item = cart.find(item => item.id === productId);
    if (item) {
        item.quantity += change;
        if (item.quantity <= 0) {
            removeFromCart(productId);
        } else {
            updateCartDisplay();
        }
    }
}

// Update cart display
function updateCartDisplay() {
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    const totalPrice = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

    cartCount.textContent = totalItems;
    cartTotal.textContent = totalPrice.toFixed(2);

    // Update payment total
    const paymentTotal = document.getElementById('paymentTotal');
    if (paymentTotal) {
        paymentTotal.textContent = totalPrice.toFixed(2);
    }

    renderCartItems();
}

// Render cart items
function renderCartItems() {
    cartItems.innerHTML = '';

    if (cart.length === 0) {
        cartItems.innerHTML = '<div class="empty-cart">Your cart is empty</div>';
        return;
    }

    cart.forEach(item => {
        const cartItem = document.createElement('div');
        cartItem.className = 'cart-item';

        cartItem.innerHTML = `
            <div class="cart-item-image">${item.icon}</div>
            <div class="cart-item-details">
                <div class="cart-item-name">${item.name}</div>
                <div class="cart-item-price">$${item.price}</div>
            </div>
            <div class="quantity-controls">
                <button class="quantity-btn" onclick="updateQuantity(${item.id}, -1)">-</button>
                <span>${item.quantity}</span>
                <button class="quantity-btn" onclick="updateQuantity(${item.id}, 1)">+</button>
            </div>
            <button class="remove-item" onclick="removeFromCart(${item.id})">
                <i class="fas fa-trash"></i>
            </button>
        `;

        cartItems.appendChild(cartItem);
    });
}

// Toggle cart
function toggleCart() {
    const isActive = cartSidebar.classList.contains('active');

    if (isActive) {
        cartSidebar.classList.remove('active');
        cartOverlay.style.display = 'none';
    } else {
        cartSidebar.classList.add('active');
        cartOverlay.style.display = 'block';
    }
}

// Checkout
function checkout() {
    if (cart.length === 0) {
        showNotification('Your cart is empty!');
        return;
    }

    toggleCart();
    paymentModal.style.display = 'flex';
}

// Close payment modal
function closePaymentModal() {
    paymentModal.style.display = 'none';
}

// Close success modal
function closeSuccessModal() {
    successModal.style.display = 'none';
}

// Format card number
function formatCardNumber(e) {
    let value = e.target.value.replace(/\s/g, '').replace(/\D/g, '');
    let formattedValue = value.replace(/(.{4})/g, '$1 ').trim();
    e.target.value = formattedValue;
}

// Format expiry date
function formatExpiryDate(e) {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length >= 2) {
        value = value.substring(0, 2) + '/' + value.substring(2, 4);
    }
    e.target.value = value;
}

// Format CVV
function formatCVV(e) {
    e.target.value = e.target.value.replace(/\D/g, '');
}

// Process payment
function processPayment(e) {
    e.preventDefault();

    // Simulate payment processing
    const payBtn = e.target.querySelector('.pay-btn');
    const originalText = payBtn.innerHTML;

    payBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
    payBtn.disabled = true;

    setTimeout(() => {
        closePaymentModal();
        successModal.style.display = 'flex';

        // Clear cart
        cart = [];
        updateCartDisplay();

        // Reset form
        document.getElementById('paymentForm').reset();
        payBtn.innerHTML = originalText;
        payBtn.disabled = false;

        showNotification('Payment successful! Thank you for your purchase.');
    }, 2000);
}

// Scroll to products
function scrollToProducts() {
    document.getElementById('products').scrollIntoView({ behavior: 'smooth' });
}

// Show notification
function showNotification(message) {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: var(--secondary-color);
        color: white;
        padding: 15px 20px;
        border-radius: 10px;
        z-index: 4000;
        transform: translateX(100%);
        transition: transform 0.3s;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
    `;

    document.body.appendChild(notification);

    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);

    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Add scroll effect to header
window.addEventListener('scroll', function() {
    const header = document.querySelector('.header');
    if (window.scrollY > 100) {
        header.style.background = 'rgba(255, 255, 255, 0.95)';
        header.style.backdropFilter = 'blur(10px)';
    } else {
        header.style.background = 'var(--white)';
        header.style.backdropFilter = 'none';
    }
});